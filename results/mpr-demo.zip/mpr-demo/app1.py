import json
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ==========================================
# PAGE CONFIG & APPLE BENTO UI CSS
# ==========================================
st.set_page_config(
    page_title="MPR Benchmark & Memory Audit",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="collapsed",
)

BENTO_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Inter", sans-serif;
        background-color: #F5F5F7;
        color: #1D1D1F;
    }

    .block-container {
        padding-top: 1.6rem;
        padding-bottom: 3rem;
        max-width: 1380px;
    }

    .hero-box {
        background: #FFFFFF;
        border: 1px solid #E5E5EA;
        border-radius: 20px;
        padding: 24px 28px;
        margin-bottom: 18px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
    }

    .hero-badge {
        display: inline-block;
        background: #E8F2FF;
        color: #0071E3;
        font-size: 0.78rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 999px;
        margin-bottom: 8px;
        letter-spacing: 0.02em;
    }

    .hero-title {
        font-size: 1.75rem;
        font-weight: 700;
        letter-spacing: -0.02em;
        margin: 0 0 6px 0;
        color: #1D1D1F;
    }

    .hero-sub {
        font-size: 0.95rem;
        color: #6E6E73;
        margin: 0;
    }

    .bento-card {
        background: #FFFFFF;
        border: 1px solid #E5E5EA;
        border-radius: 18px;
        padding: 18px 20px;
        box-shadow: 0 1px 6px rgba(0, 0, 0, 0.025);
        height: 100%;
    }

    .metric-label {
        font-size: 0.80rem;
        font-weight: 600;
        color: #6E6E73;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-bottom: 6px;
    }

    .metric-value {
        font-size: 1.85rem;
        font-weight: 700;
        color: #1D1D1F;
        letter-spacing: -0.02em;
        line-height: 1.15;
    }

    .metric-sub {
        font-size: 0.82rem;
        color: #6E6E73;
        margin-top: 6px;
    }

    .pill-ok {
        display: inline-block;
        background: #E8F8EE;
        color: #1A7F37;
        font-weight: 600;
        font-size: 0.78rem;
        padding: 3px 10px;
        border-radius: 999px;
    }

    .pill-err {
        display: inline-block;
        background: #FFEBE9;
        color: #CF222E;
        font-weight: 600;
        font-size: 0.78rem;
        padding: 3px 10px;
        border-radius: 999px;
    }

    .pill-warn {
        display: inline-block;
        background: #FFF8C5;
        color: #9A6700;
        font-weight: 600;
        font-size: 0.78rem;
        padding: 3px 10px;
        border-radius: 999px;
    }

    div[data-baseweb="tab-list"] {
        gap: 8px;
        background: #FFFFFF;
        padding: 6px;
        border-radius: 14px;
        border: 1px solid #E5E5EA;
        margin-bottom: 16px;
    }

    button[data-baseweb="tab"] {
        border-radius: 10px !important;
        padding: 8px 16px !important;
        font-weight: 600 !important;
        font-size: 0.9rem !important;
    }
</style>
"""
st.markdown(BENTO_CSS, unsafe_allow_html=True)

DATA_DIR = Path(__file__).parent / "data"


@st.cache_data(show_spinner=False)
def load_json(filename: str) -> Optional[Any]:
    fp = DATA_DIR / filename
    if not fp.exists():
        return None
    with open(fp, "r", encoding="utf-8") as f:
        return json.load(f)


def bento_kpi(label: str, value: str, sub: str = ""):
    st.markdown(
        f"""
        <div class="bento-card">
            <div class="metric-label">{label}</div>
            <div class="metric-value">{value}</div>
            <div class="metric-sub">{sub}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def style_plotly(fig: go.Figure, height: int = 380) -> go.Figure:
    fig.update_layout(
        template="plotly_white",
        height=height,
        margin=dict(l=20, r=20, t=42, b=24),
        paper_bgcolor="#FFFFFF",
        plot_bgcolor="#FFFFFF",
        font=dict(family="Inter, -apple-system, sans-serif", color="#1D1D1F", size=12),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    return fig


# Load all 6 pre-computed artifacts
audit_32k = load_json("1_audit_retrieval_32k.json")
topk_sweep = load_json("2_topk_sweep.json")
matched_bench = load_json("3_matched_benchmark.json")
deep_traces = load_json("4_deep_traces_30q.json")
hybrid_lora = load_json("5_hybridmem_real_lora.json")
asksft_ab = load_json("6_asksft_ab_results.json")

# ==========================================
# HEADER
# ==========================================
st.markdown(
    """
    <div class="hero-box">
        <div class="hero-badge">arXiv:2508.13250v1 · Independent Replication & Audit</div>
        <div class="hero-title">Explicit vs. Implicit Memory in Multi-Hop Personalized Reasoning (MPR)</div>
        <p class="hero-sub">
            Qwen2.5-7B-Instruct (4-bit NF4) · 32,400 Questions (Hop 2–10) · 0-VRAM Retrieval (BM25s & E5-base-v2) · Real Multi-LoRA across 5 K-means Clusters
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

tab1, tab2, tab3, tab4 = st.tabs([
    "1. Executive Benchmark & Cost",
    "2. Reasoning Trace Inspector",
    "3. Scale Retrieval & Data Audit",
    "4. Implicit Memory & HybridMem",
])

# ==========================================
# TAB 1: EXECUTIVE BENCHMARK & COST-EFFICIENCY
# ==========================================
with tab1:
    if not matched_bench or not matched_bench.get("results"):
        st.warning("Missing `3_matched_benchmark.json` in `data/`.")
    else:
        df_b = pd.DataFrame(matched_bench["results"])
        df_b["label"] = df_b.apply(
            lambda r: f"{r['method']} [{r['retriever'].upper()}]"
            if r["retriever"] not in ("none", "oracle")
            else r["method"],
            axis=1,
        )
        df_b["ci_low"] = df_b["em_all_ci95"].apply(
            lambda x: x[0] if isinstance(x, list) and len(x) == 2 else 0.0
        )
        df_b["ci_high"] = df_b["em_all_ci95"].apply(
            lambda x: x[1] if isinstance(x, list) and len(x) == 2 else 0.0
        )
        df_b["err_plus"] = (df_b["ci_high"] - df_b["em_all_pct"]).clip(lower=0)
        df_b["err_minus"] = (df_b["em_all_pct"] - df_b["ci_low"]).clip(lower=0)

        oracle_best = df_b[df_b["retriever"] == "oracle"]["em_all_pct"].max()
        rag_rows = df_b[df_b["retriever"].isin(["bm25", "e5"])]
        rag_best_row = rag_rows.loc[rag_rows["em_all_pct"].idxmax()] if not rag_rows.empty else None
        ignoramus_row = df_b[df_b["retriever"] == "none"]
        ign_em = float(ignoramus_row["em_all_pct"].iloc[0]) if not ignoramus_row.empty else 0.0

        mr_rows = df_b[df_b["run_id"].str.contains("s5_mr", na=False)]
        mr_dup_str = "N/A"
        if not mr_rows.empty and "mr_duplicate_stats" in mr_rows.columns:
            rates = [
                x.get("duplicate_question_rate_pct", 0)
                for x in mr_rows["mr_duplicate_stats"].dropna().tolist()
                if isinstance(x, dict)
            ]
            if rates:
                mr_dup_str = f"{np.mean(rates):.1f}%"

        c1, c2, c3, c4 = st.columns(4)
        with c1:
            bento_kpi(
                "Oracle Ceiling (EM)",
                f"{oracle_best:.2f}%",
                "Upper bound when 100% gold supporting evidence is supplied",
            )
        with c2:
            if rag_best_row is not None:
                bento_kpi(
                    "Best RAG Configuration",
                    f"{rag_best_row['em_all_pct']:.2f}%",
                    f"{rag_best_row['label']} · {rag_best_row['avg_calls_per_q']} calls/Q",
                )
        with c3:
            bento_kpi(
                "Ignoramus Baseline",
                f"{ign_em:.2f}%",
                "Zero retrieval (measures parametric prior & leakage)",
            )
        with c4:
            bento_kpi(
                "MR Sibling Duplication",
                mr_dup_str,
                "Questions with duplicate sampled sibling branches (temp=0.7)",
            )

        st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)

        col_l, col_r = st.columns([1.25, 1.0])
        with col_l:
            df_sorted = df_b.sort_values("em_all_pct", ascending=True)
            color_map = {"oracle": "#34C759", "bm25": "#0071E3", "e5": "#5856D6", "none": "#8E8E93"}
            fig_em = go.Figure()
            fig_em.add_trace(
                go.Bar(
                    y=df_sorted["label"],
                    x=df_sorted["em_all_pct"],
                    orientation="h",
                    marker_color=[color_map.get(r, "#0071E3") for r in df_sorted["retriever"]],
                    error_x=dict(
                        type="data",
                        symmetric=False,
                        array=df_sorted["err_plus"],
                        arrayminus=df_sorted["err_minus"],
                        color="#1D1D1F",
                        thickness=1.3,
                    ),
                    text=[f"{v:.1f}%" for v in df_sorted["em_all_pct"]],
                    textposition="outside",
                )
            )
            fig_em.update_layout(
                title="Normalized EM (%) with Bootstrap 95% CI (2,000 resamples, n=306)",
                xaxis_title="Exact Match (%)",
                xaxis=dict(range=[0, min(105, df_sorted["ci_high"].max() + 12)]),
            )
            st.plotly_chart(style_plotly(fig_em, height=460), use_container_width=True)

        with col_r:
            fig_pareto = px.scatter(
                df_b,
                x="avg_calls_per_q",
                y="em_all_pct",
                size=df_b["avg_latency_s"].clip(lower=0.5),
                color="retriever",
                text="method",
                color_discrete_map={"oracle": "#34C759", "bm25": "#0071E3", "e5": "#5856D6", "none": "#8E8E93"},
                title="Cost-Efficiency Frontier: LLM Calls/Query vs. EM (%)",
                labels={"avg_calls_per_q": "Average LLM Calls / Question", "em_all_pct": "EM (%)"},
            )
            fig_pareto.update_traces(textposition="top center", textfont_size=10)
            st.plotly_chart(style_plotly(fig_pareto, height=460), use_container_width=True)

        # EM degradation across Hop depth (Hop 2 -> Hop 10)
        hop_records = []
        for _, row in df_b.iterrows():
            by_hop = row.get("by_hop_em_pct") or {}
            for h_str, val in by_hop.items():
                if int(h_str) > 0:
                    hop_records.append({"Method": row["label"], "Hop": int(h_str), "EM (%)": val})

        if hop_records:
            df_hop = pd.DataFrame(hop_records).sort_values("Hop")
            selected_methods = st.multiselect(
                "Select configurations to compare EM degradation across Hop depth (2 → 10):",
                options=df_b["label"].tolist(),
                default=[
                    x
                    for x in df_b["label"].tolist()
                    if any(
                        k in x
                        for k in [
                            "Oracle NR",
                            "NR (k=20) [BM25]",
                            "SR-5 [BM25]",
                            "MR (3-Branch) [BM25]",
                            "DR (Blind Decomp) [BM25]",
                        ]
                    )
                ][:5],
            )
            if selected_methods:
                fig_hop = px.line(
                    df_hop[df_hop["Method"].isin(selected_methods)],
                    x="Hop",
                    y="EM (%)",
                    color="Method",
                    markers=True,
                    title="Reasoning Robustness Across Evidence Chain Depth (Hop 2 → Hop 10)",
                )
                fig_hop.update_xaxes(dtick=1)
                st.plotly_chart(style_plotly(fig_hop, height=360), use_container_width=True)

        # Quantitative summary table
        st.subheader("Quantitative Summary Table (Matched 306 Questions)")
        display_df = df_b[
            ["label", "em_all_pct", "em_all_ci95", "em_unflagged_pct", "avg_calls_per_q", "avg_latency_s"]
        ].rename(
            columns={
                "label": "Configuration",
                "em_all_pct": "EM All (%)",
                "em_all_ci95": "95% CI",
                "em_unflagged_pct": "EM Unflagged (%)",
                "avg_calls_per_q": "Calls / Q",
                "avg_latency_s": "Latency (s)",
            }
        )
        st.dataframe(display_df, use_container_width=True, hide_index=True)

# ==========================================
# TAB 2: REASONING TRACE INSPECTOR
# ==========================================
with tab2:
    if not deep_traces or not deep_traces.get("traces"):
        st.warning("Missing `4_deep_traces_30q.json` in `data/`.")
    else:
        traces = deep_traces["traces"]
        hops_avail = sorted(list({t["hop"] for t in traces}))

        fc1, fc2 = st.columns([1, 2.5])
        with fc1:
            sel_hop = st.selectbox("Filter by Hop count:", options=["All"] + hops_avail)
        filtered = [t for t in traces if sel_hop == "All" or t["hop"] == sel_hop]

        with fc2:
            q_labels = [f"[Hop {t['hop']}] QID {t['qid']} — {t['question'][:85]}..." for t in filtered]
            sel_idx = st.selectbox(
                "Select a question to inspect reasoning traces:",
                range(len(filtered)),
                format_func=lambda i: q_labels[i],
            )

        item = filtered[sel_idx]
        st.markdown(
            f"""
            <div class="bento-card" style="margin-bottom:14px;">
                <div class="metric-label">Question · Hop {item['hop']} · QID {item['qid']}</div>
                <div style="font-size:1.1rem; font-weight:600; margin-bottom:8px;">{item['question']}</div>
                <div><span class="pill-ok">Gold Answer: {item['gold_answer']}</span></div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        runs = item.get("runs", {})
        run_ids = list(runs.keys())

        # Quick comparison matrix for this question
        comp_rows = []
        for rid, rdata in runs.items():
            dup = rdata.get("dup_branches", 0)
            comp_rows.append({
                "Run ID": rid,
                "Method": rdata.get("method"),
                "Retriever": str(rdata.get("retriever", "")).upper(),
                "Prediction": rdata.get("pred"),
                "EM": "✅ Correct" if rdata.get("em", 0) >= 1.0 else "❌ Wrong",
                "Calls": rdata.get("calls"),
                "Latency (s)": round(float(rdata.get("latency_s", 0)), 2),
                "Sibling Duplication": f"⚠️ {dup} duplicate(s)" if dup > 0 else "—",
            })
        st.dataframe(pd.DataFrame(comp_rows), use_container_width=True, hide_index=True)

        st.markdown("#### Side-by-Side Step-by-Step Trace Comparison")
        c_left, c_right = st.columns(2)
        default_l = next((i for i, r in enumerate(run_ids) if "sr5_bm25" in r), 0)
        default_r = next((i for i, r in enumerate(run_ids) if "mr_bm25" in r), min(1, len(run_ids) - 1))

        def render_trace_panel(col, key_suffix: str, default_index: int):
            with col:
                chosen = st.selectbox(
                    f"Configuration {key_suffix}:",
                    options=run_ids,
                    index=default_index,
                    key=f"trace_sel_{key_suffix}",
                )
                rd = runs[chosen]
                badge = (
                    '<span class="pill-ok">EM = 1.0</span>'
                    if rd.get("em", 0) >= 1
                    else '<span class="pill-err">EM = 0.0</span>'
                )
                dup_badge = (
                    f' <span class="pill-warn">⚠️ {rd.get("dup_branches")} duplicate branch(es)</span>'
                    if rd.get("dup_branches", 0) > 0
                    else ""
                )
                st.markdown(
                    f"""
                    <div class="bento-card" style="margin-bottom:10px;">
                        <div class="metric-label">{rd.get('method')} ({str(rd.get('retriever')).upper()})</div>
                        <div style="margin:6px 0;">{badge}{dup_badge}</div>
                        <div><b>Prediction:</b> {rd.get('pred') or '<i>(empty)</i>'}</div>
                        <div class="metric-sub">Calls: {rd.get('calls')} · Latency: {rd.get('latency_s', 0):.2f}s</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                trace_data = rd.get("trace")
                if isinstance(trace_data, list) and trace_data:
                    for step_i, step in enumerate(trace_data, 1):
                        with st.expander(f"Step / Evidence #{step_i}", expanded=(step_i <= 3)):
                            if isinstance(step, (dict, list)):
                                st.json(step)
                            else:
                                st.write(step)
                elif isinstance(trace_data, dict):
                    st.json(trace_data)
                else:
                    st.info("No intermediate reasoning trace logged for this configuration (Single-pass / No-retrieval).")

        render_trace_panel(c_left, "A", default_l)
        render_trace_panel(c_right, "B", default_r)

# ==========================================
# TAB 3: SCALE RETRIEVAL & DATA AUDIT LAB
# ==========================================
with tab3:
    st.subheader("1. Full-Scale Dataset & Retrieval Audit (32,400 Questions, Hop 2–10)")

    def extract_audit_series(obj: Any):
        hop_rows = []
        if isinstance(obj, dict):
            for k in ["by_hop", "hops", "hop_stats", "retrieval_by_hop", "recall_by_hop"]:
                if k in obj and isinstance(obj[k], dict):
                    for h_k, v in obj[k].items():
                        if str(h_k).isdigit() and isinstance(v, dict):
                            hop_rows.append({"Hop": int(h_k), **v})
                    if hop_rows:
                        break
        return pd.DataFrame(hop_rows).sort_values("Hop") if hop_rows else pd.DataFrame()

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        bento_kpi("Total Audited Questions", "32,400", "12 user knowledge graphs (~13,084 statements/user)")
    with k2:
        bento_kpi("Full Recall @ Hop 10 (k=20)", "1.6% vs 0.5%", "BM25 (1.6%) vs. E5-base-v2 (0.5%)")
    with k3:
        bento_kpi("Recall@20 Crossover", "Hop 3 → 4", "E5 leads Hop 2–3 (99.0% / 59.3%); BM25 leads from Hop 4+")
    with k4:
        bento_kpi("Numeric Overlap", "51.78%", "Rises to 80.4% at Hop 10 (numeric artifact overlap)")

    st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)

    df_audit = extract_audit_series(audit_32k)
    if not df_audit.empty:
        num_cols = [c for c in df_audit.columns if c != "Hop" and pd.api.types.is_numeric_dtype(df_audit[c])]
        if num_cols:
            fig_aud = px.line(
                df_audit,
                x="Hop",
                y=num_cols[:6],
                markers=True,
                title="Retrieval Recall & Audit Metrics by Hop Depth (32,400 Questions)",
            )
            fig_aud.update_xaxes(dtick=1)
            st.plotly_chart(style_plotly(fig_aud, height=360), use_container_width=True)
    elif audit_32k is not None:
        with st.expander("Inspect Raw Audit JSON (`1_audit_retrieval_32k.json`)", expanded=False):
            st.json(audit_32k)

    st.divider()
    st.subheader("2. S3 Top-k Sweep: Scaling Context Window (k = 10 → 50) on 900 Questions")
    if not topk_sweep or not topk_sweep.get("retrievers"):
        st.warning("Missing `2_topk_sweep.json` in `data/`.")
    else:
        sweep_rows = []
        hop_sweep_rows = []
        for ret_name, k_dict in topk_sweep["retrievers"].items():
            for _, kv in k_dict.items():
                sweep_rows.append({
                    "Retriever": ret_name.upper(),
                    "Top-k": kv["k"],
                    "Full Recall (%)": kv["overall_full_recall_pct"],
                    "EM (%)": kv["overall_em_pct"],
                })
                for h_str, hv in (kv.get("by_hop") or {}).items():
                    if int(h_str) > 0:
                        hop_sweep_rows.append({
                            "Retriever": ret_name.upper(),
                            "Top-k": f"k={kv['k']}",
                            "Hop": int(h_str),
                            "EM (%)": hv["em_pct"],
                            "Full Recall (%)": hv["full_recall_pct"],
                        })

        df_sw = pd.DataFrame(sweep_rows).sort_values(["Retriever", "Top-k"])
        sc1, sc2 = st.columns(2)
        with sc1:
            fig_sw_em = px.line(
                df_sw,
                x="Top-k",
                y="EM (%)",
                color="Retriever",
                markers=True,
                color_discrete_map={"BM25": "#0071E3", "E5": "#5856D6"},
                title="Impact of Top-k on Exact Match (NR Mode, n=900)",
            )
            fig_sw_em.update_xaxes(tickvals=[10, 20, 30, 50])
            st.plotly_chart(style_plotly(fig_sw_em, height=350), use_container_width=True)

        with sc2:
            fig_sw_rec = px.line(
                df_sw,
                x="Top-k",
                y="Full Recall (%)",
                color="Retriever",
                markers=True,
                color_discrete_map={"BM25": "#0071E3", "E5": "#5856D6"},
                title="100% Gold Evidence Coverage (Full Recall) vs. Top-k",
            )
            fig_sw_rec.update_xaxes(tickvals=[10, 20, 30, 50])
            st.plotly_chart(style_plotly(fig_sw_rec, height=350), use_container_width=True)

        if hop_sweep_rows:
            ret_pick = st.radio("Select retriever for per-Hop Top-k breakdown:", ["BM25", "E5"], horizontal=True)
            df_hs = pd.DataFrame(hop_sweep_rows)
            fig_hs = px.line(
                df_hs[df_hs["Retriever"] == ret_pick].sort_values("Hop"),
                x="Hop",
                y="EM (%)",
                color="Top-k",
                markers=True,
                title=f"EM Across Hops by Top-k Cutoff ({ret_pick})",
            )
            fig_hs.update_xaxes(dtick=1)
            st.plotly_chart(style_plotly(fig_hs, height=340), use_container_width=True)

# ==========================================
# TAB 4: IMPLICIT MEMORY & HYBRIDMEM REALITY CHECK
# ==========================================
with tab4:
    if not hybrid_lora:
        st.warning("Missing `5_hybridmem_real_lora.json` in `data/`.")
    else:
        meta = hybrid_lora.get("meta", {})
        s_seen = hybrid_lora.get("summary", {}).get("seen", {})
        s_para = hybrid_lora.get("summary", {}).get("paraphrased", {})

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            bento_kpi(
                "Cluster Routing Acc (Seen / Para)",
                f"{s_seen.get('cluster_routing_acc', 0):.1f}% / {s_para.get('cluster_routing_acc', 0):.1f}%",
                f"Top-{meta.get('top_k', 5)} majority voting across {meta.get('n_clusters', 5)} K-means clusters",
            )
        with m2:
            bento_kpi(
                "Implicit LoRA Only (Seen / Para)",
                f"{s_seen.get('implicit_lora_only_em', 0):.1f}% / {s_para.get('implicit_lora_only_em', 0):.1f}%",
                "Cluster LoRA active without retrieved context",
            )
        with m3:
            bento_kpi(
                "Plain Retrieval (Seen / Para)",
                f"{s_seen.get('plain_retrieval_em', 0):.1f}% / {s_para.get('plain_retrieval_em', 0):.1f}%",
                "Adapters disabled (disable_adapter); explicit RAG only",
            )
        with m4:
            bento_kpi(
                "HybridMem Real Multi-LoRA",
                f"{s_seen.get('hybridmem_multi_lora_em', 0):.1f}% / {s_para.get('hybridmem_multi_lora_em', 0):.1f}%",
                f"set_adapter(voted_cluster) + RAG ({meta.get('base_model', '')})",
            )

        st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)

        hc1, hc2 = st.columns([1.05, 1.15])
        with hc1:
            comp_lora = pd.DataFrame([
                {"Split": "Seen (n=60)", "Mode": "Implicit LoRA Only", "EM (%)": s_seen.get("implicit_lora_only_em", 0)},
                {"Split": "Seen (n=60)", "Mode": "Plain Retrieval", "EM (%)": s_seen.get("plain_retrieval_em", 0)},
                {"Split": "Seen (n=60)", "Mode": "HybridMem Multi-LoRA", "EM (%)": s_seen.get("hybridmem_multi_lora_em", 0)},
                {"Split": "Paraphrased (n=60)", "Mode": "Implicit LoRA Only", "EM (%)": s_para.get("implicit_lora_only_em", 0)},
                {"Split": "Paraphrased (n=60)", "Mode": "Plain Retrieval", "EM (%)": s_para.get("plain_retrieval_em", 0)},
                {"Split": "Paraphrased (n=60)", "Mode": "HybridMem Multi-LoRA", "EM (%)": s_para.get("hybridmem_multi_lora_em", 0)},
            ])
            fig_lora = px.bar(
                comp_lora,
                x="Split",
                y="EM (%)",
                color="Mode",
                barmode="group",
                text_auto=".1f",
                color_discrete_map={
                    "Implicit LoRA Only": "#FF9500",
                    "Plain Retrieval": "#0071E3",
                    "HybridMem Multi-LoRA": "#34C759",
                },
                title="Reality Check: Implicit LoRA vs. Plain RAG vs. HybridMem Multi-LoRA",
            )
            st.plotly_chart(style_plotly(fig_lora, height=390), use_container_width=True)

        with hc2:
            pts = hybrid_lora.get("cluster_visualization", [])
            if pts:
                df_pts = pd.DataFrame(pts)
                df_pts["Cluster"] = df_pts["cluster"].apply(lambda c: f"LoRA_Cluster_{c}")
                df_pts["snippet"] = df_pts["text"].str.slice(0, 110)
                fig_pca = px.scatter(
                    df_pts,
                    x="x",
                    y="y",
                    color="Cluster",
                    hover_data={"snippet": True, "x": False, "y": False, "Cluster": True},
                    title=f"K-means Clustering of {meta.get('num_statements', 400)} Statements (2D PCA Projection)",
                )
                fig_pca.update_traces(marker=dict(size=7, opacity=0.82))
                st.plotly_chart(style_plotly(fig_pca, height=390), use_container_width=True)

        # Training loss curves for the 5 real LoRA adapters
        t_logs = hybrid_lora.get("training_logs", {})
        if t_logs:
            loss_rows = []
            for cname, cinfo in t_logs.items():
                for ep_i, lval in enumerate(cinfo.get("epoch_losses", []), 1):
                    loss_rows.append({
                        "Adapter": cname,
                        "Epoch": ep_i,
                        "Loss": lval,
                        "Facts": cinfo.get("num_facts", 0),
                    })
            if loss_rows:
                fig_loss = px.line(
                    pd.DataFrame(loss_rows),
                    x="Epoch",
                    y="Loss",
                    color="Adapter",
                    markers=True,
                    title="Training Loss Convergence Across 5 Real LoRA Adapters (Dynamic Batch Padding)",
                )
                fig_loss.update_xaxes(dtick=1)
                st.plotly_chart(style_plotly(fig_loss, height=300), use_container_width=True)

        # Per-sample inspection table
        st.markdown("#### Per-Query Verification (Seen vs. Paraphrased)")
        split_label = st.radio("Select evaluation split:", ["Seen", "Paraphrased"], horizontal=True)
        split_choice = split_label.lower()
        samples = hybrid_lora.get("samples", {}).get(split_choice, [])
        if samples:
            sample_rows = []
            for s in samples:
                sample_rows.append({
                    "ID": s["id"],
                    "Question": s["question"],
                    "Gold Answer": s["gold_answer"],
                    "Cluster Route": f"C{s['voted_cluster']} ({'✅' if s['route_correct'] else '❌ Gold C' + str(s['gold_cluster'])})",
                    "Implicit LoRA": f"{s['implicit_lora']['pred']} ({'✅' if s['implicit_lora']['em'] else '❌'})",
                    "Plain RAG": f"{s['plain_retrieval']['pred']} ({'✅' if s['plain_retrieval']['em'] else '❌'})",
                    "HybridMem LoRA": f"{s['hybridmem_lora']['pred']} ({'✅' if s['hybridmem_lora']['em'] else '❌'})",
                })
            st.dataframe(pd.DataFrame(sample_rows), use_container_width=True, hide_index=True)

    # Supplementary: 1-Hop Implicit Probe (AskSFT A/B)
    if asksft_ab is not None:
        st.divider()
        st.subheader("Supplementary: 1-Hop Implicit Probe (`6_asksft_ab_results.json`)")
        if isinstance(asksft_ab, list) and asksft_ab and isinstance(asksft_ab[0], dict):
            st.dataframe(pd.DataFrame(asksft_ab), use_container_width=True, hide_index=True)
        else:
            with st.expander("View AskSFT A/B Probe Results", expanded=True):
                st.json(asksft_ab)
