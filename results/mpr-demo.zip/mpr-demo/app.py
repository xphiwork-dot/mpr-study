import streamlit as st
import pandas as pd
import plotly.express as px
import json
import requests

# ==========================================
# 1. PAGE CONFIG & CUSTOM CSS (APPLE / BENTO STYLE)
# ==========================================
st.set_page_config(
    page_title="MPR Benchmark — Explicit vs. Hybrid Memory",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="collapsed"
)

st.markdown("""
<style>
    /* Apple-inspired Typography & Global Background */
    html, body, [class*="css"] {
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Inter", "Segoe UI", Roboto, sans-serif;
    }
    .stApp {
        background-color: #F5F5F7;
        color: #1D1D1F;
    }
    /* Hide default Streamlit chrome for a standalone web app feel */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {background: transparent !important;}

    /* Hero Header */
    .hero-box {
        background: linear-gradient(135deg, #FFFFFF 0%, #F0F4FF 100%);
        border: 1px solid rgba(0,0,0,0.06);
        border-radius: 20px;
        padding: 28px 32px;
        margin-bottom: 24px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.03);
    }
    .hero-title {
        font-size: 2.1rem;
        font-weight: 700;
        letter-spacing: -0.03em;
        background: linear-gradient(90deg, #1D1D1F 0%, #0071E3 60%, #7C3AED 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 6px;
    }
    .hero-sub {
        font-size: 1rem;
        color: #6E6E73;
        margin-bottom: 14px;
    }

    /* Pill Badges */
    .pill {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 999px;
        font-size: 0.78rem;
        font-weight: 600;
        margin-right: 8px;
        letter-spacing: 0.01em;
    }
    .pill-blue { background: #E8F2FF; color: #0071E3; }
    .pill-purple { background: #F3E8FF; color: #7C3AED; }
    .pill-green { background: #E6F8EC; color: #15803D; }
    .pill-red { background: #FEE2E2; color: #B91C1C; }
    .pill-gray { background: #E5E7EB; color: #374151; }

    /* Bento Card */
    .bento-card {
        background: #FFFFFF;
        border: 1px solid rgba(0,0,0,0.06);
        border-radius: 18px;
        padding: 20px 22px;
        margin-bottom: 16px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.03);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .bento-card:hover {
        box-shadow: 0 8px 24px rgba(0,0,0,0.06);
    }
    .kpi-value {
        font-size: 2rem;
        font-weight: 700;
        color: #1D1D1F;
        letter-spacing: -0.02em;
    }
    .kpi-label {
        font-size: 0.85rem;
        color: #6E6E73;
        font-weight: 500;
    }

    /* Statement & Reasoning Trace Boxes */
    .stmt-golden {
        background: #ECFDF5;
        border-left: 4px solid #10B981;
        padding: 10px 14px;
        border-radius: 10px;
        margin-bottom: 8px;
        font-size: 0.9rem;
    }
    .stmt-noise {
        background: #F9FAFB;
        border-left: 4px solid #D1D5DB;
        padding: 8px 14px;
        border-radius: 10px;
        margin-bottom: 8px;
        font-size: 0.86rem;
        color: #4B5563;
    }
    .thought-box {
        background: #FFFBEB;
        border: 1px solid #FDE68A;
        border-radius: 12px;
        padding: 12px 16px;
        margin-top: 10px;
        font-size: 0.92rem;
        color: #92400E;
    }
    .answer-box {
        background: #EFF6FF;
        border: 1px solid #BFDBFE;
        border-radius: 12px;
        padding: 12px 16px;
        margin-top: 10px;
        font-size: 0.95rem;
        font-weight: 600;
        color: #1E40AF;
    }

/* Modern Segmented Control Tabs (High-Contrast Fixed Theme) */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: #E2E4E9 !important;
        padding: 6px !important;
        border-radius: 14px !important;
        border: 1px solid rgba(0, 0, 0, 0.06);
    }
    .stTabs [data-baseweb="tab"] {
        background-color: transparent !important;
        border-radius: 10px !important;
        padding: 10px 20px !important;
        border: none !important;
        transition: all 0.2s ease !important;
    }
    /* Force unselected tab text color */
    .stTabs [data-baseweb="tab"] p,
    .stTabs [data-baseweb="tab"] div {
        color: #4B5563 !important;
        font-weight: 600 !important;
        font-size: 0.95rem !important;
    }
    /* Hover state for unselected tabs */
    .stTabs [data-baseweb="tab"]:hover {
        background-color: rgba(255, 255, 255, 0.6) !important;
    }
    .stTabs [data-baseweb="tab"]:hover p {
        color: #1D1D1F !important;
    }
    /* Active (selected) tab */
    .stTabs [aria-selected="true"] {
        background-color: #FFFFFF !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
    }
    .stTabs [aria-selected="true"] p,
    .stTabs [aria-selected="true"] div {
        color: #0071E3 !important;
        font-weight: 700 !important;
    }
    /* Hide default Streamlit red underline indicator */
    .stTabs [data-baseweb="tab-highlight"] {
        background-color: transparent !important;
    }
    .stTabs [data-baseweb="tab-border"] {
        display: none !important;
    }
</style>
""", unsafe_allow_html=True)

# ==========================================
# 2. DATA LOADING
# ==========================================
@st.cache_data
def load_json_safe(path: str):
    """Safely load a JSON file and return None if not found."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None

trace_data = load_json_safe("rich_demo_traces.json")
ab_data = load_json_safe("asksft_ab_results.json")

# ==========================================
# 3. SIDEBAR (SETTINGS & BACKEND STATUS)
# ==========================================
with st.sidebar:
    st.markdown("### ⚙️ Presentation Settings")
    show_noise = st.toggle("Show distractor statements (Noise) in RAG", value=True)
    api_url = st.text_input("Kaggle Live API URL (Optional)", placeholder="https://xxxx.trycloudflare.com")
    if api_url:
        try:
            ok = requests.get(f"{api_url.rstrip('/')}/docs", timeout=2).status_code == 200
            st.success("GPU Backend: ONLINE") if ok else st.warning("Backend returned unexpected status")
        except Exception:
            st.error("GPU Backend: OFFLINE")
    st.divider()
    st.caption("Paper: arXiv:2508.13250v1\nHost: demo.tinydevops.io.vn")

# ==========================================
# 4. HERO HEADER
# ==========================================
st.markdown("""
<div class="hero-box">
    <div class="hero-title">Explicit vs. Hybrid Memory</div>
    <div class="hero-sub">Exploring Multi-hop Complex Reasoning Over Personalized Information</div>
    <div>
        <span class="pill pill-blue">arXiv:2508.13250v1</span>
        <span class="pill pill-purple">Qwen2.5-3B + e5-base-v2</span>
        <span class="pill pill-green">Explicit RAG & HybridMem</span>
        <span class="pill pill-gray">AskSFT A/B/C Testing</span>
    </div>
</div>
""", unsafe_allow_html=True)

# ==========================================
# 5. MAIN NAVIGATION TABS
# ==========================================
tab_trace, tab_ab, tab_perf = st.tabs([
    "🔍 Step-by-Step Hop Visualizer",
    "🧪 A/B/C Testing: Implicit Memory (AskSFT)",
    "📊 Performance Analytics & Data"
])

# ------------------------------------------
# TAB 1: STEP-BY-STEP HOP VISUALIZER
# ------------------------------------------
with tab_trace:
    if not trace_data or not trace_data.get("cases"):
        st.warning("File `rich_demo_traces.json` not found. Please download it from Kaggle into the app directory.")
    else:
        cases = trace_data["cases"]

        # Compact Bento Filter Bar
        f1, f2, f3, f4 = st.columns([1.4, 1.2, 1.8, 1.2])
        with f1:
            source_filter = st.selectbox("Dataset Source", ["All", "Custom Use Cases", "MPR Benchmark"])
        with f2:
            all_hops = sorted(list(set(c["hop"] for c in cases)))
            hop_filter = st.selectbox("Complexity (Hops)", ["All"] + [f"{h}-Hop" for h in all_hops])
        with f3:
            search_kw = st.text_input("Search Question", placeholder="Enter keyword (e.g., Phoenix, Memo...)")
        with f4:
            playback_mode = st.toggle("Step Playback Mode", value=False)

        # Apply filters
        filtered = []
        for c in cases:
            if source_filter == "Custom Use Cases" and not c["is_custom"]:
                continue
            if source_filter == "MPR Benchmark" and c["is_custom"]:
                continue
            if hop_filter != "All" and f"{c['hop']}-Hop" != hop_filter:
                continue
            if search_kw and search_kw.lower() not in c["question"].lower():
                continue
            filtered.append(c)

        if not filtered:
            st.info("No test cases match the current filters.")
        else:
            labels = [f"[{c['hop']}-Hop] {'⭐ CUSTOM | ' if c['is_custom'] else ''}{c['id']} — {c['question'][:85]}..." for c in filtered]
            idx = st.selectbox("Select Test Case:", range(len(filtered)), format_func=lambda i: labels[i])
            case = filtered[idx]

            # Question & Golden References Card
            gold_html = "".join([f"<div class='stmt-golden'>🎯 {s}</div>" for s in case["golden_statements"]])
            st.markdown(f"""
            <div class="bento-card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <span class="pill pill-blue">{case['hop']}-Hop Reasoning</span>
                    <span class="pill pill-green">Ground Truth: {case['ground_truth']}</span>
                </div>
                <div style="font-size:1.08rem; font-weight:600; color:#1D1D1F; margin-bottom:14px;">
                    {case['question']}
                </div>
                <div style="font-size:0.85rem; font-weight:600; color:#6E6E73; margin-bottom:6px;">Golden References (Required Evidence):</div>
                {gold_html}
            </div>
            """, unsafe_allow_html=True)

            # Optional Step Playback Slider
            max_s = len(case["explicit"]["steps"])
            visible_step = max_s
            if playback_mode:
                visible_step = st.slider("Reasoning Step Playback:", 1, max_s, 1)

            # Side-by-Side Comparison: Explicit vs HybridMem
            col_exp, col_hyb = st.columns(2, gap="medium")

            def render_method_column(col, res, title, is_hybrid=False):
                with col:
                    status_pill = "<span class='pill pill-green'>✓ CORRECT</span>" if res["is_correct"] else "<span class='pill pill-red'>✕ INCORRECT</span>"
                    st.markdown(f"""
                    <div class="bento-card" style="padding:16px 20px;">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span style="font-size:1.15rem; font-weight:700;">{title}</span>
                            {status_pill}
                        </div>
                        <div style="margin-top:8px; font-size:0.9rem; color:#4B5563;">
                            Prediction: <b>{res['final_answer']}</b> &nbsp;|&nbsp; Latency: <b>{res['latency']}s</b>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    for step in res["steps"][:visible_step]:
                        step_header = f"Step {step['step']} • {step['type']}"
                        if is_hybrid and step.get("active_lora"):
                            step_header += f" • ⚡ {step['active_lora']}"

                        with st.expander(step_header, expanded=True):
                            # K-means Cluster Voting visualization for HybridMem
                            if is_hybrid and step.get("cluster_votes"):
                                total_v = sum(step["cluster_votes"].values()) or 1
                                st.markdown(f"**K-means Cluster Voting** → Activated `{step['active_lora']}`")
                                for cid, cnt in sorted(step["cluster_votes"].items(), key=lambda x: -x[1]):
                                    st.progress(cnt / total_v, text=f"Cluster {cid}: {cnt}/{total_v} votes")

                            # Top-k Retrieved Statements
                            st.markdown("**Retrieved Context (Top-k DenseRAG):**")
                            for r in step["retrieved"]:
                                if r["is_golden"]:
                                    st.markdown(
                                        f"<div class='stmt-golden'><b>[GOLDEN EVIDENCE]</b> "
                                        f"<span class='pill pill-gray'>Score: {r['score']}</span> "
                                        f"<span class='pill pill-purple'>Cluster {r['cluster']}</span><br>{r['text']}</div>",
                                        unsafe_allow_html=True
                                    )
                                elif show_noise:
                                    st.markdown(
                                        f"<div class='stmt-noise'><i>[Distractor]</i> (Score: {r['score']} | Cluster {r['cluster']}) — {r['text']}</div>",
                                        unsafe_allow_html=True
                                    )

                            # Step Output (Thought or Final Answer)
                            if step["type"] == "Thinking":
                                st.markdown(f"<div class='thought-box'>💭 <b>Thought Step {step['step']}:</b> {step['output']}</div>", unsafe_allow_html=True)
                            else:
                                st.markdown(f"<div class='answer-box'>🎯 <b>Final Answer:</b> {step['output']}</div>", unsafe_allow_html=True)

            render_method_column(col_exp, case["explicit"], "Explicit Memory (DenseRAG)", is_hybrid=False)
            render_method_column(col_hyb, case["hybrid"], "HybridMem (K-means + LoRA)", is_hybrid=True)

# ------------------------------------------
# TAB 2: A/B/C TESTING (IMPLICIT MEMORY - ASKSFT)
# ------------------------------------------
with tab_ab:
    if not ab_data:
        st.info("File `asksft_ab_results.json` not found. Export it from Kaggle into the app directory to enable A/B/C Testing.")
    else:
        titles = [c["title"] for c in ab_data]
        sel_ab = st.selectbox("Select A/B/C Test Scenario:", range(len(titles)), format_func=lambda i: titles[i])
        item = ab_data[sel_ab]

        st.markdown(f"""
        <div class="bento-card">
            <span class="pill pill-purple">{item['hop']}-Hop Test</span>
            <span class="pill pill-green">Ground Truth: {item['ground_truth']}</span>
            <div style="font-size:1.1rem; font-weight:600; margin-top:10px;">{item['question']}</div>
        </div>
        """, unsafe_allow_html=True)

        with st.expander("View Retrieved Context (Provided only to Column 3 - ASO / Hybrid)"):
            st.code(item["context"], language="text")

        c1, c2, c3 = st.columns(3, gap="medium")

        def render_ab_bento(col, title, desc, res_obj, gt):
            is_ok = gt.lower() in res_obj["answer"].lower()
            badge = "<span class='pill pill-green'>✓ CORRECT</span>" if is_ok else "<span class='pill pill-red'>✕ INCORRECT</span>"
            border_color = "#10B981" if is_ok else "#EF4444"
            with col:
                st.markdown(f"""
                <div class="bento-card" style="border-top: 4px solid {border_color}; min-height: 210px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <span style="font-weight:700; font-size:1.05rem;">{title}</span>
                        {badge}
                    </div>
                    <div style="font-size:0.82rem; color:#6E6E73; margin-bottom:14px;">{desc}</div>
                    <div style="font-size:1rem; font-weight:600; color:#1D1D1F; background:#F9FAFB; padding:12px; border-radius:10px; margin-bottom:12px;">
                        {res_obj['answer']}
                    </div>
                    <div style="font-size:0.85rem; color:#6E6E73;">⏱ Latency: <b>{res_obj['latency']}s</b></div>
                </div>
                """, unsafe_allow_html=True)

        render_ab_bento(c1, "1. Base Model", "No personalized fine-tuning, no retrieved context.", item["base"], item["ground_truth"])
        render_ab_bento(c2, "2. AskSFT (Implicit)", "LoRA fine-tuned on 1-hop QA pairs, no retrieved context.", item["asksft"], item["ground_truth"])
        render_ab_bento(c3, "3. AskSFT + Context (ASO)", "Combines LoRA weights with retrieved text context.", item["aso"], item["ground_truth"])

        # Latency Comparison Chart
        lat_df = pd.DataFrame([
            {"Model": "1. Base Model", "Latency (s)": item["base"]["latency"]},
            {"Model": "2. AskSFT (Implicit)", "Latency (s)": item["asksft"]["latency"]},
            {"Model": "3. AskSFT + Context (ASO)", "Latency (s)": item["aso"]["latency"]},
        ])
        fig_ab_lat = px.bar(
            lat_df, x="Model", y="Latency (s)", color="Model", text_auto=".2f",
            color_discrete_sequence=["#9CA3AF", "#7C3AED", "#0071E3"],
            title="Inference Latency Comparison (Efficiency)"
        )
        fig_ab_lat.update_layout(plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)", showlegend=False, height=320)
        st.plotly_chart(fig_ab_lat, use_container_width=True)

# ------------------------------------------
# TAB 3: PERFORMANCE ANALYTICS & DATA
# ------------------------------------------
with tab_perf:
    if not trace_data or not trace_data.get("cases"):
        st.warning("No data available in `rich_demo_traces.json`.")
    else:
        cases = trace_data["cases"]
        rows = []
        for c in cases:
            rows.append({
                "ID": c["id"],
                "Hop": f"{c['hop']}-Hop",
                "Method": "Explicit Memory (RAG)",
                "Correct": int(c["explicit"]["is_correct"]),
                "Latency (s)": c["explicit"]["latency"],
                "Prediction": c["explicit"]["final_answer"],
                "Ground Truth": c["ground_truth"]
            })
            rows.append({
                "ID": c["id"],
                "Hop": f"{c['hop']}-Hop",
                "Method": "HybridMem",
                "Correct": int(c["hybrid"]["is_correct"]),
                "Latency (s)": c["hybrid"]["latency"],
                "Prediction": c["hybrid"]["final_answer"],
                "Ground Truth": c["ground_truth"]
            })
        df_perf = pd.DataFrame(rows)

        exp_acc = df_perf[df_perf["Method"] == "Explicit Memory (RAG)"]["Correct"].mean() * 100
        hyb_acc = df_perf[df_perf["Method"] == "HybridMem"]["Correct"].mean() * 100
        avg_lat = df_perf["Latency (s)"].mean()

        # 4 Bento KPI Cards
        k1, k2, k3, k4 = st.columns(4)
        k1.markdown(f"<div class='bento-card'><div class='kpi-label'>Total Test Cases</div><div class='kpi-value'>{len(cases)}</div></div>", unsafe_allow_html=True)
        k2.markdown(f"<div class='bento-card'><div class='kpi-label'>Explicit Memory Acc</div><div class='kpi-value' style='color:#0071E3;'>{exp_acc:.1f}%</div></div>", unsafe_allow_html=True)
        k3.markdown(f"<div class='bento-card'><div class='kpi-label'>HybridMem Acc</div><div class='kpi-value' style='color:#10B981;'>{hyb_acc:.1f}%</div></div>", unsafe_allow_html=True)
        k4.markdown(f"<div class='bento-card'><div class='kpi-label'>Average Latency</div><div class='kpi-value'>{avg_lat:.2f}s</div></div>", unsafe_allow_html=True)

        # Accuracy & Latency Charts
        g1, g2 = st.columns(2)
        with g1:
            acc_hop = df_perf.groupby(["Hop", "Method"], as_index=False)["Correct"].mean()
            acc_hop["Accuracy (%)"] = acc_hop["Correct"] * 100
            fig_acc = px.bar(
                acc_hop, x="Hop", y="Accuracy (%)", color="Method", barmode="group", text_auto=".1f",
                color_discrete_map={"Explicit Memory (RAG)": "#0071E3", "HybridMem": "#10B981"},
                title="Exact Match Accuracy by Hop Count"
            )
            fig_acc.update_layout(plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig_acc, use_container_width=True)

        with g2:
            lat_hop = df_perf.groupby(["Hop", "Method"], as_index=False)["Latency (s)"].mean()
            fig_lat = px.line(
                lat_hop, x="Hop", y="Latency (s)", color="Method", markers=True,
                color_discrete_map={"Explicit Memory (RAG)": "#0071E3", "HybridMem": "#10B981"},
                title="Average Latency by Hop Count"
            )
            fig_lat.update_layout(plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig_lat, use_container_width=True)

        # Detailed Data Table & CSV Export
        st.markdown("### Detailed Evaluation Results")
        st.dataframe(df_perf, use_container_width=True, hide_index=True)
        st.download_button(
            "⬇️ Download Results (CSV)",
            data=df_perf.to_csv(index=False).encode("utf-8"),
            file_name="mpr_benchmark_results.csv",
            mime="text/csv"
        )
